<img align="right" src="https://raw.githubusercontent.com/vroncevic/${PRO}/dev/docs/${PRO}_logo.png" width="25%">

# ${PRO}

**${PRO}** ${DESCRIPTION}.

Developed in **[Embedded C](https://en.wikipedia.org/wiki/Embedded_C)** code: **100%**.

The README is used to introduce the modules and provide instructions on
how to install the modules, any machine dependencies it may have and any
other information that should be provided before the modules are installed.

[![GitHub issues open](https://img.shields.io/github/issues/vroncevic/${PRO}.svg)](${REPO_URL}/issues) [![GitHub contributors](https://img.shields.io/github/contributors/vroncevic/${PRO}.svg)](${REPO_URL}/graphs/contributors)

<!-- START doctoc generated TOC please keep comment here to allow auto update -->
<!-- DON'T EDIT THIS SECTION, INSTEAD RE-RUN doctoc TO UPDATE -->
**Table of Contents**

- [Installation](#installation)
- [Dependencies](#dependencies)
- [App Library structure](#app-library-structure)
- [Docs](#docs)
- [Copyright and Licence](#copyright-and-licence)

<!-- END doctoc generated TOC please keep comment here to allow auto update -->

### Installation

Navigate to **[release page](${REPO_URL}/releases)** download and extract release archive.

To install **${PRO}** type the following

```bash
tar xvzf ${PRO}-x.y.z.tar.gz
cd ${PRO}-x.y.z
```

You can use docker to create image/container.

### Dependencies

**${PRO}** requires next modules and libraries

* TODO

### App Library structure

**${PRO}** is based on POP

App/Library structure

```bash

```

### Docs

[![Documentation Status](https://readthedocs.org/projects/${PRO}/badge/?version=latest)](https://${PRO}.readthedocs.io/projects/${PRO}/en/latest/?badge=latest)

More documentation and info at
* [${PRO}.readthedocs.io](https://${PRO}.readthedocs.io/en/latest/)
* [www.raspberrypi.org](https://www.raspberrypi.org)

### Copyright and Licence

[![License: GPL v3](https://img.shields.io/badge/License-GPLv3-blue.svg)](https://www.gnu.org/licenses/gpl-3.0) [![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)

Copyright (C) ${YEAR} by [${AUTHOR_NAME}](${AUTHOR_URL})

**${PRO}** is free software; you can redistribute it and/or modify it.

Lets help and support RPIF.

[![Raspberry Pi Foundation](https://raw.githubusercontent.com/vroncevic/${PRO}/dev/docs/psf-logo-alpha.png)](https://www.raspberrypi.org)

[![Donate](https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif)](https://www.raspberrypi.org/support-us/)
